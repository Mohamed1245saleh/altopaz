<?php
$servername = 'localhost';
$username = 'u191962684_topaz';
$password = 'QnTOR7zDOk8mgJ1!';
$dbname = 'u191962684_topaz';
$conn=new mysqli($servername ,$username ,$password ,$dbname ) or die("failing to connect to the DB");
$conn->set_charset('utf8');
?>
